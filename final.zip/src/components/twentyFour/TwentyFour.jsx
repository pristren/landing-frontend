const TwentyFour = () => {
  return (
    <section className="container mx-auto py-10 px-5">
      {/* title  */}
      <div className="text-center mb-20">
        <h5 className="text-lg">RESEÑAS DE NUESTROS CLIENTES</h5>
        <h2 className="text-4xl font-bold">Lo que dicen de nosotros</h2>
      </div>

      {/* reviews container  */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 md:gap-8 lg:gap-10">
        {/* review 1 */}
        <div className="shadow p-8">
          {/* <h3 className="text-xl font-semibold mb-10">
            Con diferencia el más agil y con mejor user experience
          </h3> */}
          <p className="text-gray-700 font-medium mb-8">
            Una herramienta indispensable para la gestión comunitaria.
            HappyVecinos ha simplificado nuestra contabilidad y comunicación.
            ¡Imprescindible para cualquier administrador!
          </p>

          {/* rating icon  */}
          <div className="flex items-center mb-10">
            <svg
              className="w-6 h-6  mr-4"
              aria-hidden="true"
              xmlns="http://www.w3.org/2000/svg"
              fill="#21c55d"
              viewBox="0 0 22 20"
            >
              <path d="M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z" />
            </svg>
            <svg
              className="w-6 h-6 mr-4"
              aria-hidden="true"
              xmlns="http://www.w3.org/2000/svg"
              fill="#21c55d"
              viewBox="0 0 22 20"
            >
              <path d="M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z" />
            </svg>
            <svg
              className="w-6 h-6  mr-4"
              aria-hidden="true"
              xmlns="http://www.w3.org/2000/svg"
              fill="#21c55d"
              viewBox="0 0 22 20"
            >
              <path d="M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z" />
            </svg>
            <svg
              className="w-6 h-6 mr-4"
              aria-hidden="true"
              xmlns="http://www.w3.org/2000/svg"
              fill="#21c55d"
              viewBox="0 0 22 20"
            >
              <path d="M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z" />
            </svg>
            <svg
              className="w-6 h-6 mr-4 text-gray-300 dark:text-gray-500"
              aria-hidden="true"
              xmlns="http://www.w3.org/2000/svg"
              fill="#21c55d"
              viewBox="0 0 22 20"
            >
              <path d="M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z" />
            </svg>
          </div>
          {/* date  */}
          <div>
            <h3 className="font-medium text-lg">
              Marta López, Administradora de &apos;Edificio Mirador
            </h3>
            {/* <p className="text-gray-700 font-medium">27 de febrero 2023</p> */}
          </div>
        </div>
        {/* review 2 */}
        <div className="shadow p-8">
          {/* <h3 className="text-xl font-semibold mb-10">
            Con diferencia el más agil y con mejor user experience
          </h3> */}
          <p className="text-gray-700 font-medium mb-8">
            La experiencia de usuario es inmejorable. Con HappyVecinos, la
            gestión de incidencias y reservas es más fácil que nunca. ¡Los
            vecinos están encantados!
          </p>

          {/* rating icon  */}
          <div className="flex items-center mb-10">
            <svg
              className="w-6 h-6  mr-4"
              aria-hidden="true"
              xmlns="http://www.w3.org/2000/svg"
              fill="#21c55d"
              viewBox="0 0 22 20"
            >
              <path d="M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z" />
            </svg>
            <svg
              className="w-6 h-6 mr-4"
              aria-hidden="true"
              xmlns="http://www.w3.org/2000/svg"
              fill="#21c55d"
              viewBox="0 0 22 20"
            >
              <path d="M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z" />
            </svg>
            <svg
              className="w-6 h-6  mr-4"
              aria-hidden="true"
              xmlns="http://www.w3.org/2000/svg"
              fill="#21c55d"
              viewBox="0 0 22 20"
            >
              <path d="M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z" />
            </svg>
            <svg
              className="w-6 h-6 mr-4"
              aria-hidden="true"
              xmlns="http://www.w3.org/2000/svg"
              fill="#21c55d"
              viewBox="0 0 22 20"
            >
              <path d="M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z" />
            </svg>
            <svg
              className="w-6 h-6 mr-4 text-gray-300 dark:text-gray-500"
              aria-hidden="true"
              xmlns="http://www.w3.org/2000/svg"
              fill="#21c55d"
              viewBox="0 0 22 20"
            >
              <path d="M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z" />
            </svg>
          </div>
          {/* date  */}
          <div>
            <h3 className="font-medium text-lg">
              José Fernández, Presidente de &apos;Residencial La Paz
            </h3>
            {/* <p className="text-gray-700 font-medium">27 de febrero 2023</p> */}
          </div>
        </div>
        {/* review 3 */}
        <div className="shadow p-8">
          {/* <h3 className="text-xl font-semibold mb-10">
            Con diferencia el más agil y con mejor user experience
          </h3> */}
          <p className="text-gray-700 font-medium mb-8">
            El soporte y las funcionalidades de HappyVecinos han mejorado
            significativamente el bienestar de nuestra comunidad. Es mucho más
            que un software, es parte de nuestro día a día.
          </p>

          {/* rating icon  */}
          <div className="flex items-center mb-10">
            <svg
              className="w-6 h-6  mr-4"
              aria-hidden="true"
              xmlns="http://www.w3.org/2000/svg"
              fill="#21c55d"
              viewBox="0 0 22 20"
            >
              <path d="M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z" />
            </svg>
            <svg
              className="w-6 h-6 mr-4"
              aria-hidden="true"
              xmlns="http://www.w3.org/2000/svg"
              fill="#21c55d"
              viewBox="0 0 22 20"
            >
              <path d="M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z" />
            </svg>
            <svg
              className="w-6 h-6  mr-4"
              aria-hidden="true"
              xmlns="http://www.w3.org/2000/svg"
              fill="#21c55d"
              viewBox="0 0 22 20"
            >
              <path d="M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z" />
            </svg>
            <svg
              className="w-6 h-6 mr-4"
              aria-hidden="true"
              xmlns="http://www.w3.org/2000/svg"
              fill="#21c55d"
              viewBox="0 0 22 20"
            >
              <path d="M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z" />
            </svg>
            <svg
              className="w-6 h-6 mr-4 text-gray-300 dark:text-gray-500"
              aria-hidden="true"
              xmlns="http://www.w3.org/2000/svg"
              fill="#21c55d"
              viewBox="0 0 22 20"
            >
              <path d="M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z" />
            </svg>
          </div>
          {/* date  */}
          <div>
            <h3 className="font-medium text-lg">
              Ana Gutiérrez, Miembro del Comité de &apos;Parque Sol
            </h3>
            {/* <p className="text-gray-700 font-medium">27 de febrero 2023</p> */}
          </div>
        </div>
      </div>

      {/* review bottom  */}
      <div>
        <div className="flex items-center mb-2 mt-8 justify-center">
          <h3 className="font-bold mr-5">Excelente</h3>
          <svg
            className="w-6 h-6  mr-4"
            aria-hidden="true"
            xmlns="http://www.w3.org/2000/svg"
            fill="#10b880"
            viewBox="0 0 22 20"
          >
            <path d="M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z" />
          </svg>
          <svg
            className="w-6 h-6 mr-4"
            aria-hidden="true"
            xmlns="http://www.w3.org/2000/svg"
            fill="#10b880"
            viewBox="0 0 22 20"
          >
            <path d="M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z" />
          </svg>
          <svg
            className="w-6 h-6  mr-4"
            aria-hidden="true"
            xmlns="http://www.w3.org/2000/svg"
            fill="#10b880"
            viewBox="0 0 22 20"
          >
            <path d="M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z" />
          </svg>
          <svg
            className="w-6 h-6 mr-4"
            aria-hidden="true"
            xmlns="http://www.w3.org/2000/svg"
            fill="#10b880"
            viewBox="0 0 22 20"
          >
            <path d="M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z" />
          </svg>
          <svg
            className="w-6 h-6 mr-4 text-gray-300 dark:text-gray-500"
            aria-hidden="true"
            xmlns="http://www.w3.org/2000/svg"
            fill="#10b880"
            viewBox="0 0 22 20"
          >
            <path d="M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z" />
          </svg>
        </div>
        <p className="text-center">
          valoracion <b>4,4</b> de <b>1,200</b> reasenas en Trustpilot
        </p>
      </div>
    </section>
  );
};

export default TwentyFour;

// Mucha ayuda y atención
// Siempre que hemos tenido que realizar algún cambio o necesitábamos ayuda, los trabajadores del chat han sido amables, efectivos y rápidos. Estamos....
// Resolución de problemas
// Tuve un problemilla de configuración y me lo resolvieron estupendamente. Atención personalizada y pronta resolución de problemas.

// Estela 2 de marzo 2023
// Aitziber 2 de marzo 2023
